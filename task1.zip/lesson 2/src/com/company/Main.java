package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        if (scn.hasNextInt()) {
            if (scn.nextInt() % 2 == 0) {
                System.out.println("Четное число");
            } else {
                System.out.println("Нечетное число");
            }
        } else {
            System.out.println("Нецелое число");
        }
    }
}
